"""Content identity and isolated snapshots for small disposable Git repositories."""

from __future__ import annotations

import hashlib
import os
import shutil
import stat
import subprocess
from pathlib import Path
from typing import Any

from .contracts import RUN_ID_RE

SKIP_NAMES = frozenset(
    {".git", ".venv", "node_modules", "__pycache__", ".pytest_cache", ".ruff_cache"}
)


def _git(repo: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repo), *args], capture_output=True, text=True, check=True
    )
    return completed.stdout.strip()


def validate_paths(repo: Path, state_dir: Path, *, require_clean: bool) -> None:
    repo = repo.resolve(strict=True)
    state_dir = state_dir.resolve()
    if not repo.is_dir() or _git(repo, "rev-parse", "--show-toplevel") != str(repo):
        raise ValueError("repository must be a Git working-copy root")
    if state_dir == repo or repo in state_dir.parents or state_dir in repo.parents:
        raise ValueError("state directory and repository must be disjoint")
    if require_clean and _git(repo, "status", "--porcelain=v1", "--untracked-files=all"):
        raise ValueError("repository must start clean; use a disposable working copy")


def _files(root: Path) -> list[Path]:
    # The source repository may contain ignored credentials or dependency trees.
    # Only Git-visible files form the review candidate. Snapshots have no .git,
    # so walking them also detects new files created during a gate.
    if (root / ".git").exists():
        listing = subprocess.run(
            [
                "git",
                "-C",
                str(root),
                "ls-files",
                "-z",
                "--cached",
                "--others",
                "--exclude-standard",
            ],
            capture_output=True,
            check=True,
        ).stdout
        paths = []
        for raw in listing.split(b"\0"):
            if not raw:
                continue
            relative = Path(os.fsdecode(raw))
            if any(part in SKIP_NAMES for part in relative.parts):
                continue
            path = root / relative
            if not path.exists() and not path.is_symlink():
                continue  # a deleted tracked file is absent from the candidate
            _validate_candidate_file(root, path)
            paths.append(path)
        return _check_symlink_targets(root, paths)
    paths: list[Path] = []
    for base, dirs, files in os.walk(root, followlinks=False):
        for name in dirs:
            directory = Path(base, name)
            if directory.is_symlink():
                raise ValueError(f"candidate contains a symlinked directory: {directory}")
        dirs[:] = sorted(name for name in dirs if name not in SKIP_NAMES)
        for name in sorted(files):
            if name in SKIP_NAMES:
                continue
            path = Path(base, name)
            _validate_candidate_file(root, path)
            paths.append(path)
    return _check_symlink_targets(root, paths)


def _check_symlink_targets(root: Path, paths: list[Path]) -> list[Path]:
    selected = sorted(set(paths))
    # Every file reachable through a selected link must itself participate in
    # the candidate hash. An ignored target could otherwise change between
    # review and verification without changing the candidate ID.
    visible_regular = {
        path.resolve(strict=True) for path in selected if path.is_file() and not path.is_symlink()
    }
    for path in selected:
        if path.is_symlink() and path.resolve(strict=True) not in visible_regular:
            raise ValueError(f"candidate symlink target is not Git-visible: {path}")
    return selected


def _validate_candidate_file(root: Path, path: Path) -> None:
    # Git can still list a tracked `dir/file` after `dir` is ignored and
    # replaced by a link. Check every lexical parent before opening the file;
    # otherwise its bytes may come from outside the candidate checkout.
    parent = root
    for component in path.relative_to(root).parts[:-1]:
        parent /= component
        parent_mode = parent.lstat().st_mode
        if not stat.S_ISDIR(parent_mode) or stat.S_ISLNK(parent_mode):
            raise ValueError(f"candidate contains a symlinked or non-directory ancestor: {parent}")
    mode = path.lstat().st_mode
    if stat.S_ISREG(mode):
        return
    if stat.S_ISLNK(mode):
        target_name = os.readlink(path)
        if os.path.isabs(target_name):
            raise ValueError(f"candidate symlink points outside its checkout: {path}")
        target = path.resolve(strict=True)
        if root.resolve() not in target.parents or not target.is_file():
            raise ValueError(f"candidate symlink points outside a regular checkout file: {path}")
        lexical = Path(os.path.normpath(str(path.parent / target_name)))
        if not lexical.is_relative_to(root) or target != root.resolve() / lexical.relative_to(root):
            raise ValueError(f"candidate symlink traverses another link: {path}")
        return
    raise ValueError(f"candidate contains a special file: {path}")


def content_hash(root: Path) -> str:
    hasher = hashlib.sha256()
    for path in _files(root):
        relative = path.relative_to(root).as_posix()
        hasher.update(relative.encode("utf-8") + b"\0")
        if path.is_symlink():
            hasher.update(b"l" + os.readlink(path).encode("utf-8") + b"\0")
            continue
        hasher.update(b"x" if path.stat().st_mode & stat.S_IXUSR else b"-")
        with path.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                hasher.update(chunk)
        hasher.update(b"\0")
    return hasher.hexdigest()


def candidate_for(repo: Path, *, head: str | None = None) -> dict[str, str]:
    head = head or _git(repo, "rev-parse", "HEAD")
    content = content_hash(repo)
    return {
        "head": head,
        "content_sha256": content,
        "id": hashlib.sha256(f"{head}:{content}".encode()).hexdigest(),
    }


def assert_candidate(repo: Path, candidate: dict[str, Any], *, git_head: bool = True) -> None:
    current = candidate_for(repo, head=None if git_head else str(candidate["head"]))
    if current["id"] != candidate["id"]:
        raise ValueError("candidate content changed after its identity was recorded")


def snapshot(repo: Path, state_dir: Path, run_id: str, candidate: dict[str, Any]) -> Path:
    if not RUN_ID_RE.fullmatch(run_id):
        raise ValueError("invalid run ID")
    destination = state_dir / "runs" / run_id / "candidate"
    if destination.exists():
        raise ValueError("candidate snapshot already exists; recovery requires inspection")
    destination.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    destination.mkdir(mode=0o700)
    for path in _files(repo):
        copied = destination / path.relative_to(repo)
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copied, follow_symlinks=False)
    assert_candidate(destination, candidate, git_head=False)
    return destination
